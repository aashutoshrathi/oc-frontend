Foodster API
=================

This API is made to be used in Foodster App.

The endpoints are:

 - `/getPlaces/:lat/:long`: To get places around lat, long.
 - `/getDetail/:placeId`: to get details about a place.