export const MAP_API_KEY = "AIzaSyC1NwVT6afM1_lL4pliNt15elTySxGQqrY";
export const DINE_ICON =
  "https://maps.gstatic.com/mapfiles/place_api/icons/restaurant-71.png";
export const ZOOM = 15;
export const API_URL = "https://foodster.glitch.me/getPlaces/";
export const DETAIL_URL = "https://foodster.glitch.me/getDetail/";
export const refPic = ref =>
  `https://maps.googleapis.com/maps/api/place/photo?photoreference=${ref}&sensor=false&maxheight=310&maxwidth=310&key=${MAP_API_KEY}`;
