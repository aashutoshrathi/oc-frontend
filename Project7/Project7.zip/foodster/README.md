# foodster

## ToDos by 3rd Nov

- Sync Restaurants List and Map
- Add new Restaurants
- Filters (Optional)
